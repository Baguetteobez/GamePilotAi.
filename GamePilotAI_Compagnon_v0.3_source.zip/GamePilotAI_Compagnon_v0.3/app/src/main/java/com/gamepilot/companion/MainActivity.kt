package com.gamepilot.companion

import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { GamePilotScreen(this) } }
    }
}

@Composable
private fun GamePilotScreen(activity: ComponentActivity) {
    var dragons by remember { mutableIntStateOf(3) }
    var hp by remember { mutableFloatStateOf(100f) }
    var mana by remember { mutableFloatStateOf(90f) }
    var dropMinutes by remember { mutableIntStateOf(4) }
    var dropActive by remember { mutableStateOf(false) }
    var secondsLeft by remember { mutableIntStateOf(240) }
    var circuitNote by remember { mutableStateOf("Circuit habituel") }
    var ocrText by remember { mutableStateOf("Aucune capture analysée.") }
    var analyzing by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) {
            analyzing = true
            try {
                val bitmap: Bitmap = if (Build.VERSION.SDK_INT >= 28) {
                    val source = ImageDecoder.createSource(activity.contentResolver, uri)
                    ImageDecoder.decodeBitmap(source) { decoder, _, _ -> decoder.isMutableRequired = false }
                } else {
                    @Suppress("DEPRECATION")
                    MediaStore.Images.Media.getBitmap(activity.contentResolver, uri)
                }
                val image = InputImage.fromBitmap(bitmap, 0)
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                    .process(image)
                    .addOnSuccessListener { result ->
                        ocrText = result.text.ifBlank { "Aucun texte reconnu. Essaie une capture plus nette." }
                        analyzing = false
                    }
                    .addOnFailureListener { e ->
                        ocrText = "Échec de l'analyse : ${e.localizedMessage ?: "erreur inconnue"}"
                        analyzing = false
                    }
            } catch (e: Exception) {
                ocrText = "Impossible d'ouvrir cette image : ${e.localizedMessage ?: "erreur"}"
                analyzing = false
            }
        }
    }

    LaunchedEffect(dropActive) {
        while (dropActive && secondsLeft > 0) {
            delay(1000)
            secondsLeft -= 1
        }
        if (secondsLeft == 0) dropActive = false
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("GamePilot AI", style = MaterialTheme.typography.headlineMedium)
        Text("Compagnon visuel • version 0.2")
        Card {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Profil", style = MaterialTheme.typography.titleMedium)
                Text("Mythxc Arus • Niveau 381 • Arc • Dragon Lv.250")
                Text("Distance 463 • Defense 429 • Speed 452")
            }
        }
        Card {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Analyse d'une capture Rucoy", style = MaterialTheme.typography.titleMedium)
                Text("Choisis une capture d'écran du jeu : l'application essaiera d'en lire le texte (niveaux, chiffres et libellés visibles).")
                Button(onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                    Text("Choisir une capture")
                }
                if (analyzing) LinearProgressIndicator(Modifier.fillMaxWidth())
                Text(ocrText, style = MaterialTheme.typography.bodySmall)
                Text("La reconnaissance OCR ne détecte pas encore les sprites des dragons ni les objets au sol.")
            }
        }
        Card {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("Suivi manuel", style = MaterialTheme.typography.titleMedium)
                Text("Dragons suivis : $dragons / 3")
                Slider(value = dragons.toFloat(), onValueChange = { dragons = it.toInt() }, valueRange = 0f..3f, steps = 2)
                Text("PV estimés : ${hp.toInt()} %")
                Slider(value = hp, onValueChange = { hp = it }, valueRange = 0f..100f)
                Text("Mana estimé : ${mana.toInt()} %")
                Slider(value = mana, onValueChange = { mana = it }, valueRange = 0f..100f)
                Text(when {
                    hp < 25 -> "ALERTE : PV bas — sécurise ton personnage."
                    mana < 20 -> "Mana bas — vérifie tes ressources."
                    dragons < 3 -> "Groupe incomplet : $dragons dragon(s) noté(s)."
                    else -> "Groupe de trois déclaré."
                })
            }
        }
        Card {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("Compte à rebours des drops", style = MaterialTheme.typography.titleMedium)
                Text("Durée estimée : 3 à 5 minutes")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    (3..5).forEach { n ->
                        OutlinedButton(onClick = { dropMinutes = n; secondsLeft = n * 60 }) { Text("$n min") }
                    }
                }
                Text("Temps restant : %d:%02d".format(secondsLeft / 60, secondsLeft % 60))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { secondsLeft = dropMinutes * 60; dropActive = true }) { Text("Nouveau drop") }
                    OutlinedButton(onClick = { dropActive = false; secondsLeft = dropMinutes * 60 }) { Text("Arrêter") }
                }
                Text(if (dropActive) "Drop à surveiller." else "Aucun compte à rebours actif.")
            }
        }
        Card {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("Circuit", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(circuitNote, { circuitNote = it }, label = { Text("Notes du parcours") }, modifier = Modifier.fillMaxWidth())
                Text("Circuit habituel ; garder les dragons proches ; ils peuvent se disperser et abandonner si tu t'éloignes trop.")
            }
        }
        Text("Cette application n'envoie aucune commande au jeu et ne joue pas à ta place.",
            style = MaterialTheme.typography.labelSmall)
    }
}
