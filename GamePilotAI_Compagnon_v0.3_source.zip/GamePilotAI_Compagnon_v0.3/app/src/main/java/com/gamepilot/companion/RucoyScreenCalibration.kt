package com.gamepilot.companion

/**
 * Repères normalisés relevés sur une capture fournie par l'utilisateur.
 * Capture de référence : 1536 x 674 px.
 *
 * Ces rectangles sont des zones candidates pour l'analyse visuelle,
 * pas un détecteur validé. Les coordonnées sont exprimées en fractions
 * de la largeur/hauteur afin de s'adapter à d'autres résolutions.
 */
data class ScreenRegion(val left: Float, val top: Float, val right: Float, val bottom: Float)

object RucoyScreenCalibration {
    const val REFERENCE_WIDTH = 1536
    const val REFERENCE_HEIGHT = 674

    // HUD haut-gauche : barre rouge PV et barre bleue secondaire.
    val healthBar = ScreenRegion(0.00f, 0.00f, 0.277f, 0.061f)
    val secondaryBar = ScreenRegion(0.00f, 0.058f, 0.277f, 0.088f)

    // Nom/niveau au-dessus du personnage sur cette capture.
    val playerLabel = ScreenRegion(0.435f, 0.379f, 0.568f, 0.423f)

    // Zone centrale de jeu à surveiller pour ennemis et objets au sol.
    val playfield = ScreenRegion(0.16f, 0.10f, 0.82f, 0.92f)

    // Commandes visibles à droite : main/action et bouton d'arc.
    val rightControls = ScreenRegion(0.83f, 0.23f, 0.92f, 0.82f)

    fun toPixels(region: ScreenRegion, width: Int, height: Int): IntArray =
        intArrayOf(
            (region.left * width).toInt(),
            (region.top * height).toInt(),
            (region.right * width).toInt(),
            (region.bottom * height).toInt()
        )
}
