# GamePilot AI Compagnon 0.3 — calibration visuelle

Cette version reprend le compagnon 0.2 et ajoute des repères de calibration normalisés
à partir de la capture fournie.

## Observations de la capture
- Résolution réelle de la capture : **1536 × 674 px** (et non 1640 × 720).
- Personnage affiché : **Mythxc Arus Lv.381**.
- Barre rouge en haut à gauche : **5 567 / 5 815 PV**.
- Une barre bleue secondaire est visible juste sous la barre rouge ; sa valeur numérique
  n'est pas lisible sur cette capture.
- Le personnage est près du centre de la zone jouable, légèrement à droite.
- Trois petits amas jaunes avec les nombres **413, 314 et 264** sont visibles près du
  personnage. La capture seule ne permet pas de confirmer s'il s'agit de drops ou d'un
  autre affichage du jeu.
- L'arc est visible dans les commandes à droite.

## Ajout technique
`RucoyScreenCalibration.kt` contient des rectangles normalisés pour la barre de PV,
la barre secondaire, le libellé du personnage, le terrain et les commandes à droite.
Ces repères sont des zones candidates basées sur une seule capture, pas une détection
automatique validée. Ils devront être ajustés avec d'autres captures, notamment avec
des dragons et un drop clairement visibles.

## Limites
- L'OCR analyse uniquement les images choisies manuellement.
- Pas de détection validée des sprites de dragons ou des objets au sol.
- Pas de capture en direct ni d'envoi de commandes au jeu.
- Le projet n'a pas été compilé ni testé sur appareil dans cet environnement.

## Compilation
Ouvrir le dossier dans Android Studio récent avec JDK 17, synchroniser Gradle puis lancer.
